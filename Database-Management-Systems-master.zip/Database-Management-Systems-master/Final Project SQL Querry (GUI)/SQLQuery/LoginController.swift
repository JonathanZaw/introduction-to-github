//
//  LoginController.swift
//  SQLQuery
//
//  Created by Huy Ong on 10/1/20.
//

import SwiftUI

struct LoginController: View {
    var body: some View {
        Text("Hello, World!")
            .frame(width: 500, height: 500)
    }
}

struct LoginController_Previews: PreviewProvider {
    static var previews: some View {
        LoginController()
    }
}
